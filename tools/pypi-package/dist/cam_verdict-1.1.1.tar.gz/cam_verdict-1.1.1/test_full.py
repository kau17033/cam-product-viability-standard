"""Full test suite for cam-verdict 1.1.0.

(i)   Canonical engine cases (same as test_port.py).
(ii)  Translator parity cases mirroring the JS translator tests
      (tools/translator/test.mjs), plus CSV / KV input forms.
(iii) MCP smoke test: spawn the stdio server, initialize + tools/list +
      tools/call the canonical cleaner case.
Plus: CLI routing through the translator (loose input in, byte-identical
output for complete canonical input).

Run: python test_full.py   (exits non-zero on any failure)
"""
import json
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, "src")
from cam_verdict.engine import evaluate
from cam_verdict.translate import parse_csv, parse_kv, translate

FAILURES = []


def check(name, cond, detail=""):
    if cond:
        print(f"PASS {name}")
    else:
        print(f"FAIL {name} {detail}")
        FAILURES.append(name)


# ---------- (i) canonical engine cases ----------
cases = [
    ({"price": 3980, "cost": 1500, "shipping": 700, "fee": 398, "returnReserve": 160, "otherVariable": 60, "deliveryDays": 5, "stock": 20, "estimateAgeDays": 74}, "HOLD", 1162),
    ({"price": 24800, "cost": 14000, "shipping": 1500, "fee": 2480, "returnReserve": 600, "otherVariable": 300, "deliveryDays": 7, "stock": 15, "estimateAgeDays": 10}, "TEST_CANDIDATE", 5920),
    ({"price": 2980, "cost": 1800, "shipping": 800, "fee": 298, "returnReserve": 100, "otherVariable": 50, "deliveryDays": 3, "stock": 50, "estimateAgeDays": 5}, "REJECT", -68),
]
for i, (p, want_v, want_p) in enumerate(cases):
    r = evaluate(p)
    check(f"engine case {i}", r["verdict"] == want_v and r["profit"] == want_p,
          f"got {r['verdict']} {r['profit']}, want {want_v} {want_p}")
r = evaluate({"price": 1980, "cost": 900, "shipping": 750, "fee": 198, "otherVariable": 0})
check("engine incomplete names returnReserve",
      bool(r["incomplete"]) and "returnReserve" in r["missing"], str(r))

# ---------- (ii) translator parity (mirrors test.mjs) ----------
today = datetime(2026, 11, 2, tzinfo=timezone(timedelta(hours=9)))
tcases = [
    ({"price": 3980, "cost": 1450, "shipping": 520, "fee": 318, "returnReserve": 160, "otherVariable": 370, "deliveryDays": 5, "stock": 20, "estimateDate": "2026-08-20"},
     "CAM verdict: HOLD — profit ¥1,162 per order"),
    ({"price": 24800, "cost": 13900, "shipping": 1100, "fee": 2480, "returnReserve": 0, "otherVariable": 1400, "deliveryDays": 3, "stock": 50, "estimateDate": "2026-10-25"},
     "CAM verdict: TEST_CANDIDATE — profit ¥5,920 per order"),
    ({"価格": 2980, "原価": 1900, "送料": 680, "手数料": 298, "返品備え": 0, "その他変動費": 170, "配送日数": 4, "在庫": 100, "見積日": "2026-10-28"},
     "CAM verdict: REJECT — profit ¥-68 per order"),
]
for i, (inp, want) in enumerate(tcases):
    got = translate(inp, today=today)["line"]
    check(f"translator case {i}", got == want, f"got {got!r} want {want!r}")
inc = translate({"price": 1000, "cost": 500}, today=today)
check("translator incomplete (4 missing)",
      inc["status"] == "INCOMPLETE" and len(inc["missing"]) == 4, json.dumps(inc, ensure_ascii=False))
# string numbers + currency marks are tolerated, never guessed
loose = translate({"selling price": "¥24,800", "purchase cost": "13,900円", "shipping": "1100",
                   "fees": "2480", "return reserve": "0", "other": "1400",
                   "delivery": "3", "inventory": "50", "quote date": "2026-10-25"}, today=today)
check("translator loose EN/string input",
      loose["line"] == "CAM verdict: TEST_CANDIDATE — profit ¥5,920 per order", str(loose.get("line")))
# CSV and KV forms reach the same verdicts
csv_raw = parse_csv("price,cost,shipping,fee,returnReserve,otherVariable,deliveryDays,stock,estimateDate\n"
                    "24800,13900,1100,2480,0,1400,3,50,2026-10-25")
check("translator CSV form",
      translate(csv_raw, today=today)["line"] == "CAM verdict: TEST_CANDIDATE — profit ¥5,920 per order")
kv_raw = parse_kv("価格: 2980\n原価: 1900\n送料: 680\n手数料: 298\n返品備え: 0\nその他変動費: 170\n配送日数: 4\n在庫: 100\n見積日: 2026-10-28")
check("translator KV form",
      translate(kv_raw, today=today)["line"] == "CAM verdict: REJECT — profit ¥-68 per order")

# ---------- CLI routing ----------
env = dict(os.environ, PYTHONPATH="src")
cleaner = {"price": 24800, "cost": 14000, "shipping": 1500, "fee": 2480,
           "returnReserve": 600, "otherVariable": 300, "deliveryDays": 7,
           "stock": 15, "estimateAgeDays": 10}
p = subprocess.run([sys.executable, "-m", "cam_verdict.cli"], input=json.dumps(cleaner),
                   capture_output=True, text=True, env=env)
check("CLI canonical input byte-identical first line",
      p.stdout.splitlines()[0] == "CAM verdict: TEST_CANDIDATE — profit ¥5920 per order",
      p.stdout + p.stderr)
p = subprocess.run([sys.executable, "-m", "cam_verdict.cli"],
                   input=json.dumps({"価格": 24800, "原価": 14000, "送料": 1500, "手数料": 2480,
                                     "返品備え": 600, "その他変動費": 300}),
                   capture_output=True, text=True, env=env)
check("CLI loose JP input routed through translator",
      p.stdout.splitlines()[0] == "CAM verdict: TEST_CANDIDATE — profit ¥5920 per order",
      p.stdout + p.stderr)

# ---------- (iii) MCP smoke test ----------
reqs = [
    {"jsonrpc": "2.0", "id": 1, "method": "initialize",
     "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                "clientInfo": {"name": "smoke", "version": "0"}}},
    {"jsonrpc": "2.0", "method": "notifications/initialized"},
    {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
    {"jsonrpc": "2.0", "id": 3, "method": "tools/call",
     "params": {"name": "cam_verdict", "arguments": cleaner}},
    {"jsonrpc": "2.0", "id": 4, "method": "tools/call",
     "params": {"name": "cam_verdict", "arguments": {"price": 1000, "cost": 500}}},
]
p = subprocess.run([sys.executable, "-m", "cam_verdict.mcp_server"],
                   input="\n".join(json.dumps(x) for x in reqs) + "\n",
                   capture_output=True, text=True, env=env)
by_id = {}
for line in p.stdout.splitlines():
    if line.strip():
        m = json.loads(line)
        if "id" in m:
            by_id[m["id"]] = m
check("MCP initialize", by_id.get(1, {}).get("result", {}).get("serverInfo", {}).get("name") == "cam-verdict",
      p.stdout + p.stderr)
tools = by_id.get(2, {}).get("result", {}).get("tools", [])
check("MCP tools/list has cam_verdict", [t.get("name") for t in tools] == ["cam_verdict"], str(tools))
text3 = by_id.get(3, {}).get("result", {}).get("content", [{}])[0].get("text", "")
check("MCP tools/call cleaner verdict",
      "TEST_CANDIDATE" in text3 and "CAM verdict: TEST_CANDIDATE — profit ¥5,920 per order" in text3, text3)
text4 = by_id.get(4, {}).get("result", {}).get("content", [{}])[0].get("text", "")
check("MCP tools/call incomplete, no verdict issued",
      text4.startswith("CAM verdict: INCOMPLETE"), text4)

print("ALL PASS" if not FAILURES else f"{len(FAILURES)} FAILURES: {FAILURES}")
sys.exit(1 if FAILURES else 0)
