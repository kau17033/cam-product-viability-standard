import sys
sys.path.insert(0, "src")
from cam_verdict.engine import evaluate

cases = [
    # vitamin C serum -> HOLD 1162 (estimate 74 days old)
    ({"price": 3980, "cost": 1500, "shipping": 700, "fee": 398, "returnReserve": 160, "otherVariable": 60, "deliveryDays": 5, "stock": 20, "estimateAgeDays": 74}, "HOLD", 1162),
    # cordless cleaner -> TEST_CANDIDATE 5920
    ({"price": 24800, "cost": 14000, "shipping": 1500, "fee": 2480, "returnReserve": 600, "otherVariable": 300, "deliveryDays": 7, "stock": 15, "estimateAgeDays": 10}, "TEST_CANDIDATE", 5920),
    # coffee beans -> REJECT -68
    ({"price": 2980, "cost": 1800, "shipping": 800, "fee": 298, "returnReserve": 100, "otherVariable": 50, "deliveryDays": 3, "stock": 50, "estimateAgeDays": 5}, "REJECT", -68),
]
for p, want_v, want_p in cases:
    r = evaluate(p)
    assert r["verdict"] == want_v and r["profit"] == want_p, (r, want_v, want_p)
    print(f"CAM verdict: {r['verdict']} — profit ¥{r['profit']} per order")
r = evaluate({"price": 1980, "cost": 900, "shipping": 750, "fee": 198, "otherVariable": 0})
assert r["incomplete"] and "returnReserve" in r["missing"]
print("incomplete case OK — missing:", r["missing"])
print("ALL PASS")
